#ifndef __LENTHEVCDEC_H__
#define __LENTHEVCDEC_H__


#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#if defined(_WIN32) || defined(WIN32)
	#define LENTAPI __stdcall
#else
	#define LENTAPI
#endif

	typedef struct lenthevcdec_frame {
		/* size in byte of this struct, initialized by caller for expand */
		int32_t size;
		/* width & height: picture size */
		int32_t width;
		int32_t height;
		/* line_stride & pixels: output picture pixel data */
		int32_t line_stride[3];
		void* pixels[3];
		/* bit depth of output picture pixel */
		int32_t bit_depth;
		/* return 1 if we got frame, then the pixels & line_stride & got_pts is valid */
		int32_t got_frame;
		/* pts of output frame */
		int64_t got_pts;
		/* 0 progressive, 1 top, 2 bottom */
		int32_t pic_struct;
		/* Sample Aspect Ratio */
		int32_t sar_width;
		int32_t sar_height;
		/**
		* MPEG vs JPEG YUV range.
			AVCOL_RANGE_UNSPECIFIED = 0,
			AVCOL_RANGE_MPEG = 1, ///< the normal 219*2^(n-8) "MPEG" YUV ranges
			AVCOL_RANGE_JPEG = 2, ///< the normal     2^n-1   "JPEG" YUV ranges
		*/
		int32_t color_range;
		/**
		* Chromaticity coordinates of the source primaries.
		* These values match the ones defined by ISO/IEC 23001-8_2013 �� 7.1.
			AVCOL_PRI_RESERVED0 = 0,
			AVCOL_PRI_BT709 = 1,  ///< also ITU-R BT1361 / IEC 61966-2-4 / SMPTE RP177 Annex B
			AVCOL_PRI_UNSPECIFIED = 2,
			AVCOL_PRI_RESERVED = 3,
			AVCOL_PRI_BT470M = 4,  ///< also FCC Title 47 Code of Federal Regulations 73.682 (a)(20)

			AVCOL_PRI_BT470BG = 5,  ///< also ITU-R BT601-6 625 / ITU-R BT1358 625 / ITU-R BT1700 625 PAL & SECAM
			AVCOL_PRI_SMPTE170M = 6,  ///< also ITU-R BT601-6 525 / ITU-R BT1358 525 / ITU-R BT1700 NTSC
			AVCOL_PRI_SMPTE240M = 7,  ///< functionally identical to above
			AVCOL_PRI_FILM = 8,  ///< colour filters using Illuminant C
			AVCOL_PRI_BT2020 = 9,  ///< ITU-R BT2020
			AVCOL_PRI_SMPTE428 = 10, ///< SMPTE ST 428-1 (CIE 1931 XYZ)
			AVCOL_PRI_SMPTEST428_1 = AVCOL_PRI_SMPTE428,
			AVCOL_PRI_SMPTE431 = 11, ///< SMPTE ST 431-2 (2011) / DCI P3
			AVCOL_PRI_SMPTE432 = 12, ///< SMPTE ST 432-1 (2010) / P3 D65 / Display P3
			AVCOL_PRI_JEDEC_P22 = 22, ///< JEDEC P22 phosphors
		*/
		int32_t color_primaries;
		/**
		* Color Transfer Characteristic.
		* These values match the ones defined by ISO/IEC 23001-8_2013 �� 7.2.
			AVCOL_TRC_RESERVED0 = 0,
			AVCOL_TRC_BT709 = 1,  ///< also ITU-R BT1361
			AVCOL_TRC_UNSPECIFIED = 2,
			AVCOL_TRC_RESERVED = 3,
			AVCOL_TRC_GAMMA22 = 4,  ///< also ITU-R BT470M / ITU-R BT1700 625 PAL & SECAM
			AVCOL_TRC_GAMMA28 = 5,  ///< also ITU-R BT470BG
			AVCOL_TRC_SMPTE170M = 6,  ///< also ITU-R BT601-6 525 or 625 / ITU-R BT1358 525 or 625 / ITU-R BT1700 NTSC
			AVCOL_TRC_SMPTE240M = 7,
			AVCOL_TRC_LINEAR = 8,  ///< "Linear transfer characteristics"
			AVCOL_TRC_LOG = 9,  ///< "Logarithmic transfer characteristic (100:1 range)"
			AVCOL_TRC_LOG_SQRT = 10, ///< "Logarithmic transfer characteristic (100 * Sqrt(10) : 1 range)"
			AVCOL_TRC_IEC61966_2_4 = 11, ///< IEC 61966-2-4
			AVCOL_TRC_BT1361_ECG = 12, ///< ITU-R BT1361 Extended Colour Gamut
			AVCOL_TRC_IEC61966_2_1 = 13, ///< IEC 61966-2-1 (sRGB or sYCC)
			AVCOL_TRC_BT2020_10 = 14, ///< ITU-R BT2020 for 10-bit system
			AVCOL_TRC_BT2020_12 = 15, ///< ITU-R BT2020 for 12-bit system
			AVCOL_TRC_SMPTE2084 = 16, ///< SMPTE ST 2084 for 10-, 12-, 14- and 16-bit systems
			AVCOL_TRC_SMPTEST2084 = AVCOL_TRC_SMPTE2084,
			AVCOL_TRC_SMPTE428 = 17, ///< SMPTE ST 428-1
			AVCOL_TRC_SMPTEST428_1 = AVCOL_TRC_SMPTE428,
			AVCOL_TRC_ARIB_STD_B67 = 18, ///< ARIB STD-B67, known as "Hybrid log-gamma"
		*/
		int32_t color_trc;
		/**
		* YUV colorspace type.
		* These values match the ones defined by ISO/IEC 23001-8_2013 �� 7.3.
			AVCOL_SPC_RGB = 0,  ///< order of coefficients is actually GBR, also IEC 61966-2-1 (sRGB)
			AVCOL_SPC_BT709 = 1,  ///< also ITU-R BT1361 / IEC 61966-2-4 xvYCC709 / SMPTE RP177 Annex B
			AVCOL_SPC_UNSPECIFIED = 2,
			AVCOL_SPC_RESERVED = 3,
			AVCOL_SPC_FCC = 4,  ///< FCC Title 47 Code of Federal Regulations 73.682 (a)(20)
			AVCOL_SPC_BT470BG = 5,  ///< also ITU-R BT601-6 625 / ITU-R BT1358 625 / ITU-R BT1700 625 PAL & SECAM / IEC 61966-2-4 xvYCC601
			AVCOL_SPC_SMPTE170M = 6,  ///< also ITU-R BT601-6 525 / ITU-R BT1358 525 / ITU-R BT1700 NTSC
			AVCOL_SPC_SMPTE240M = 7,  ///< functionally identical to above
			AVCOL_SPC_YCGCO = 8,  ///< Used by Dirac / VC-2 and H.264 FRext, see ITU-T SG16
			AVCOL_SPC_YCOCG = AVCOL_SPC_YCGCO,
			AVCOL_SPC_BT2020_NCL = 9,  ///< ITU-R BT2020 non-constant luminance system
			AVCOL_SPC_BT2020_CL = 10, ///< ITU-R BT2020 constant luminance system
			AVCOL_SPC_SMPTE2085 = 11, ///< SMPTE 2085, Y'D'zD'x
			AVCOL_SPC_CHROMA_DERIVED_NCL = 12, ///< Chromaticity-derived non-constant luminance system
			AVCOL_SPC_CHROMA_DERIVED_CL = 13, ///< Chromaticity-derived constant luminance system
			AVCOL_SPC_ICTCP = 14, ///< ITU-R BT.2100-0, ICtCp
		*/
		int32_t colorspace;
	} lenthevcdec_frame;

	typedef void* lenthevcdec_ctx;

	int             LENTAPI lenthevcdec_version(void);

	lenthevcdec_ctx LENTAPI lenthevcdec_create(int threads, int compatibility, void* reserved);

	void            LENTAPI lenthevcdec_destroy(lenthevcdec_ctx ctx);

	void            LENTAPI lenthevcdec_flush(lenthevcdec_ctx ctx);

	/* bs & bs_len: intput bitstream
	 * pts: input play timestamp
	 * out_frame: output picture warpper
	 * return: byte count used by decoder, or negative number for error
	 */
	int             LENTAPI lenthevcdec_decode_frame(lenthevcdec_ctx ctx,
							 const void* bs, int bs_len,
							 int64_t pts,
							 lenthevcdec_frame *out_frame);

#ifdef __cplusplus
}
#endif

#endif/*__LENTHEVCDEC_H__*/
