Strongene Lentoid HEVC Decoder readme file
Update Date: 2018.09.06

1. "hevcdecfltr.dll" is HEVC decoder in the form of DirectShow Filter, supporting bitstream compatible with HM9.1, HM10.0 and HM12.0, supporting LAVSplitter. The header file ilenthevcdeccfg.h is the interface to set the decoding parameters.

2. "hevcdecfltr_x64.dll" is X64 version of the HEVC decoder;

3. "FLVSplitter.ax" is a FLV splitter which is developed based on MPC-HC FLV splitter with the enhancement of HEVC support (since the native FLV format does not support HEVC codec, the solution of FLVSplitter.ax is not offical). MPC is under the GPL liscense, and if you need the source code of FLVSplitter.ax you can contact with us via service@strongene.com.

4. "mp4demux.dll" is a MP4 splitter which is developed based on GDCL Mpeg-4 File filters project (http://www.gdcl.co.uk/mpeg4/) with the enhancement of HEVC support and fully conform to the principle of GPAC. In DirectShow, the name of this registered filter is "Strongene Mpeg-4 Demultiplexor".

