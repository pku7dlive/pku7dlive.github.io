Strongene HEVC Decoder (Version: 6555)

1. usage: 	
        lentdec [--wait] [--md5] [-t <num>] [--compat 9.1|10|11|12] <input_filename> [<output_filename>]

2. options:
           -t <Int>     the number of worker threads
           --wait       wait debuger
           --md5        output md5 checksum of decoded YUV
           --compat     set HM compatibility